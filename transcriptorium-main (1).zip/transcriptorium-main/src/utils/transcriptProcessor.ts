
import { TranscriptResponse, TranscriptSegment } from "@/types/assemblyai";

export function processTranscript(transcript: TranscriptResponse): TranscriptSegment[] {
  if (!transcript.utterances || transcript.utterances.length === 0) {
    return [];
  }

  // Group words by speaker and create segments
  const segments = transcript.utterances.map(utterance => ({
    speaker: utterance.speaker,
    text: utterance.text,
    start: utterance.start,
    end: utterance.end,
    words: utterance.words || [],
    active: false,
  }));

  // Sort segments by start time to ensure chronological order
  return segments.sort((a, b) => a.start - b.start);
}
