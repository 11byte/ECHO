
export interface TranscriptRequest {
  audio_url?: string;
  audio_file?: File;
}

export interface TranscriptResponse {
  id: string;
  status: 'queued' | 'processing' | 'completed' | 'error';
  text: string;
  audio_url: string;
  words: Word[];
  utterances: Utterance[];
  error?: string;
}

export interface Word {
  text: string;
  start: number;
  end: number;
  confidence: number;
  speaker?: string;
}

export interface Utterance {
  text: string;
  start: number;
  end: number;
  speaker: string;
  words: Word[];
  confidence: number;
}

export interface TranscriptSegment {
  speaker: string;
  text: string;
  start: number;
  end: number;
  words: Word[];
  active?: boolean;
}
