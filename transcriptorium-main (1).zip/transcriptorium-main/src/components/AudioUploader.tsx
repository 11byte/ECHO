
import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

interface AudioUploaderProps {
  onFileSelected: (file: File) => void;
  isProcessing: boolean;
}

const AudioUploader = ({ onFileSelected, isProcessing }: AudioUploaderProps) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      validateAndSetFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      validateAndSetFile(file);
    }
  };

  const validateAndSetFile = (file: File) => {
    // Check if file is audio
    if (!file.type.startsWith("audio/")) {
      toast.error("Please upload an audio file");
      return;
    }
    
    // Check file size (100MB limit)
    if (file.size > 100 * 1024 * 1024) {
      toast.error("File size exceeds 100MB limit");
      return;
    }

    setSelectedFile(file);
    onFileSelected(file);
  };

  const handleButtonClick = () => {
    inputRef.current?.click();
  };

  return (
    <Card className={`border-2 ${dragActive ? 'border-brand-500 bg-brand-50' : 'border-dashed'} transition-colors duration-200`}>
      <CardContent className="p-6 text-center">
        <div
          className="space-y-4"
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <Input
            ref={inputRef}
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={handleFileChange}
            disabled={isProcessing}
          />
          
          <div className="p-4">
            <div className="rounded-full w-16 h-16 bg-brand-100 flex items-center justify-center mx-auto mb-4">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="24" 
                height="24" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="text-brand-600"
              >
                <path d="M12 8c-2.8 0-5 2.2-5 5v8h10v-8c0-2.8-2.2-5-5-5Z"></path>
                <path d="M10 8V3h4v5"></path>
                <path d="M16 15c1.7 0 3-1.3 3-3v-2"></path>
                <path d="M8 15c-1.7 0-3-1.3-3-3v-2"></path>
              </svg>
            </div>
            
            <h3 className="text-lg font-medium mb-2">Upload audio file</h3>
            <p className="text-sm text-muted-foreground mb-4">
              {selectedFile 
                ? `Selected: ${selectedFile.name}` 
                : "Drag and drop your audio file here or click to browse"}
            </p>
            
            {!selectedFile && (
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleButtonClick}
                disabled={isProcessing}
                className="hover:bg-brand-100 hover:text-brand-800 transition-colors"
              >
                Select File
              </Button>
            )}
            
            {selectedFile && (
              <div className="text-sm text-muted-foreground mt-2">
                {isProcessing ? (
                  <div className="flex items-center justify-center gap-2">
                    <div className="h-4 w-4 rounded-full bg-brand-500 animate-pulse-subtle"></div>
                    <span>Processing file...</span>
                  </div>
                ) : (
                  <div className="flex justify-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedFile(null);
                        if (inputRef.current) inputRef.current.value = '';
                      }}
                      className="text-destructive hover:text-destructive/90"
                    >
                      Remove
                    </Button>
                    <Button
                      variant="default" 
                      size="sm"
                      onClick={handleButtonClick}
                      className="bg-brand-500 hover:bg-brand-600"
                    >
                      Change
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AudioUploader;
