
import { Button } from "@/components/ui/button";

interface AppHeaderProps {
  onNewTranscriptionClick: () => void;
  isProcessing: boolean;
}

const AppHeader = ({ onNewTranscriptionClick, isProcessing }: AppHeaderProps) => {
  return (
    <header className="border-b pb-6 mb-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">TranscriptOriUM</h1>
          <p className="text-muted-foreground">Convert your audio recordings to text with timestamps and speaker identification</p>
        </div>
        <Button 
          onClick={onNewTranscriptionClick} 
          disabled={isProcessing}
          className="bg-highlight hover:bg-highlight-hover text-white"
        >
          New Transcription
        </Button>
      </div>
    </header>
  );
};

export default AppHeader;
