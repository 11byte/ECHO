
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface TranscriptionProgressProps {
  status: 'queued' | 'processing' | 'completed' | 'error' | null;
  progress: number;
}

const TranscriptionProgress = ({ status, progress }: TranscriptionProgressProps) => {
  if (!status || status === 'completed') return null;

  const getStatusText = () => {
    switch (status) {
      case 'queued':
        return 'Queued for processing...';
      case 'processing':
        return 'Transcribing audio...';
      case 'error':
        return 'Error processing transcription';
      default:
        return 'Preparing...';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{getStatusText()}</CardTitle>
      </CardHeader>
      <CardContent>
        <Progress value={progress} className="h-2 mb-2" />
        <p className="text-sm text-muted-foreground">
          {status === 'queued' 
            ? 'Your file is in queue and will be processed soon.' 
            : status === 'processing' 
              ? `Processing ${Math.round(progress)}%` 
              : 'Please wait...'}
        </p>
      </CardContent>
    </Card>
  );
};

export default TranscriptionProgress;
