
import { Card, CardContent } from "@/components/ui/card";
import { TranscriptSegment, Word } from "@/types/assemblyai";
import { formatTime, formatSpeaker } from "@/utils/formatters";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface TranscriptViewerProps {
  segments: TranscriptSegment[];
  isLoading: boolean;
}

const TranscriptViewer = ({ segments, isLoading }: TranscriptViewerProps) => {
  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="p-6">
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="h-6 w-24 bg-gray-200 rounded animate-pulse"></div>
                </div>
                <div className="h-4 bg-gray-200 rounded animate-pulse w-full"></div>
                <div className="h-4 bg-gray-200 rounded animate-pulse w-3/4"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (segments.length === 0) {
    return (
      <Card className="w-full">
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">No transcript data available yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="space-y-6">
          {segments.map((segment, index) => (
            <div 
              key={index} 
              className={cn(
                "space-y-2 p-2 -mx-2 rounded-md transition-colors", 
                segment.active ? "bg-brand-50 border-l-4 border-brand-500" : ""
              )}
              id={`segment-${segment.start}`}
            >
              <div className="flex items-center gap-2">
                <Badge variant="outline" className={cn(
                  "bg-brand-50 text-brand-800 hover:bg-brand-100",
                  segment.active ? "bg-brand-100" : ""
                )}>
                  {formatSpeaker(segment.speaker)}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {formatTime(segment.start / 1000)} - {formatTime(segment.end / 1000)}
                </span>
              </div>
              <p className="text-base leading-relaxed">{segment.text}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default TranscriptViewer;
