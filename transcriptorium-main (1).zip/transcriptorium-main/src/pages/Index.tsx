
import { useState, useEffect } from "react";
import { assemblyAIService } from "@/services/assemblyai";
import { TranscriptResponse, TranscriptSegment } from "@/types/assemblyai";
import { processTranscript } from "@/utils/transcriptProcessor";
import { toast } from "sonner";

import AudioUploader from "@/components/AudioUploader";
import TranscriptViewer from "@/components/TranscriptViewer";
import TranscriptionProgress from "@/components/TranscriptionProgress";
import AudioPlayer from "@/components/AudioPlayer";
import AppHeader from "@/components/AppHeader";
import { Card, CardContent } from "@/components/ui/card";

const Index = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [transcriptId, setTranscriptId] = useState<string | null>(null);
  const [transcriptionStatus, setTranscriptionStatus] = useState<'queued' | 'processing' | 'completed' | 'error' | null>(null);
  const [progress, setProgress] = useState(0);
  const [transcript, setTranscript] = useState<TranscriptResponse | null>(null);
  const [transcriptSegments, setTranscriptSegments] = useState<TranscriptSegment[]>([]);
  const [isInitialView, setIsInitialView] = useState(true);

  const handleFileSelected = (file: File) => {
    setSelectedFile(file);
    setIsInitialView(false);
  };

  const handleStartTranscription = async () => {
    if (!selectedFile) return;
    
    try {
      setTranscriptionStatus('queued');
      setProgress(0);
      
      // Submit file for transcription
      const id = await assemblyAIService.transcribeAudio({
        audio_file: selectedFile
      });
      
      setTranscriptId(id);
      toast.success("Audio file submitted for transcription");
      
      // Poll for status updates
      const result = await assemblyAIService.pollTranscriptionStatus(id, (update) => {
        setTranscriptionStatus(update.status);
        
        // Calculate progress based on status
        if (update.status === 'queued') {
          setProgress(10);
        } else if (update.status === 'processing') {
          // Simulate progress from 20% to 90% during processing
          setProgress(prev => Math.min(prev + 10, 90));
        } else if (update.status === 'completed') {
          setProgress(100);
        }
      });
      
      setTranscript(result);
      setTranscriptSegments(processTranscript(result));
      setTranscriptionStatus('completed');
      toast.success("Transcription completed successfully");
      
    } catch (error) {
      console.error("Transcription error:", error);
      setTranscriptionStatus('error');
      toast.error("Failed to transcribe audio");
    }
  };

  // Start transcription when file is selected
  useEffect(() => {
    if (selectedFile && !transcriptId) {
      handleStartTranscription();
    }
  }, [selectedFile]);
  
  const handleNewTranscription = () => {
    setSelectedFile(null);
    setTranscriptId(null);
    setTranscriptionStatus(null);
    setProgress(0);
    setTranscript(null);
    setTranscriptSegments([]);
    setIsInitialView(true);
  };

  // Handle audio playback time updates
  const handleTimeUpdate = (currentTime: number) => {
    if (transcriptSegments.length === 0) return;
    
    // Convert seconds to milliseconds for comparison with transcript timestamps
    const currentTimeMs = currentTime * 1000;
    
    // Create a new array with the active segment marked
    const updatedSegments = transcriptSegments.map(segment => ({
      ...segment,
      active: currentTimeMs >= segment.start && currentTimeMs <= segment.end
    }));
    
    setTranscriptSegments(updatedSegments);
    
    // Auto-scroll to the active segment
    const activeSegment = updatedSegments.find(segment => segment.active);
    if (activeSegment) {
      const elementId = `segment-${activeSegment.start}`;
      const element = document.getElementById(elementId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }
  };

  const isProcessing = transcriptionStatus === 'queued' || transcriptionStatus === 'processing';

  return (
    <div className="container py-8 max-w-4xl">
      <AppHeader 
        onNewTranscriptionClick={handleNewTranscription}
        isProcessing={isProcessing}
      />
      
      <div className="grid gap-8">
        {isInitialView ? (
          <>
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Upload an audio recording to transcribe</h2>
              <p className="text-muted-foreground">
                Supported formats: MP3, WAV, M4A and more. Max file size: 100MB
              </p>
            </div>
            <AudioUploader 
              onFileSelected={handleFileSelected}
              isProcessing={isProcessing}
            />
            <Card className="bg-brand-50 border-brand-100">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="p-2 rounded-full bg-brand-100 text-brand-800">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="24" 
                      height="24" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="M12 16v-4"></path>
                      <path d="M12 8h.01"></path>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium text-brand-800 mb-1">How it works</h3>
                    <p className="text-sm text-brand-700">
                      Upload your audio file, and we'll automatically transcribe it with speaker identification and timestamps. 
                      The transcription process typically takes a few minutes depending on the length of your recording.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        ) : (
          <>
            {isProcessing && (
              <TranscriptionProgress status={transcriptionStatus} progress={progress} />
            )}
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-1">
                <div className="space-y-6">
                  <AudioUploader 
                    onFileSelected={handleFileSelected}
                    isProcessing={isProcessing}
                  />
                  
                  {!isProcessing && selectedFile && (
                    <AudioPlayer 
                      audioFile={selectedFile} 
                      onTimeUpdate={handleTimeUpdate} 
                    />
                  )}
                </div>
              </div>
              <div className="md:col-span-2">
                <TranscriptViewer segments={transcriptSegments} isLoading={isProcessing} />
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Index;
