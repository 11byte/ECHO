
import { TranscriptRequest, TranscriptResponse } from "@/types/assemblyai";
import { toast } from "sonner";

const API_KEY = "809d698ac8874d14833cfdf230325bbe";
const API_BASE_URL = "https://api.assemblyai.com/v2";

export const assemblyAIService = {
  async uploadAudio(file: File): Promise<string> {
    try {
      const response = await fetch(`${API_BASE_URL}/upload`, {
        method: "POST",
        headers: {
          authorization: API_KEY,
        },
        body: file,
      });

      if (!response.ok) {
        throw new Error(`Upload failed with status: ${response.status}`);
      }

      const data = await response.json();
      return data.upload_url;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to upload audio";
      toast.error(errorMessage);
      throw error;
    }
  },

  async transcribeAudio(request: TranscriptRequest): Promise<string> {
    try {
      let audioUrl = request.audio_url;
      
      // If a file was provided, upload it first
      if (request.audio_file) {
        audioUrl = await this.uploadAudio(request.audio_file);
      }

      if (!audioUrl) {
        throw new Error("No audio source provided");
      }

      const response = await fetch(`${API_BASE_URL}/transcript`, {
        method: "POST",
        headers: {
          authorization: API_KEY,
          "content-type": "application/json",
        },
        body: JSON.stringify({
          audio_url: audioUrl,
          speaker_labels: true,
          auto_chapters: true,
        }),
      });

      if (!response.ok) {
        throw new Error(`Transcription request failed with status: ${response.status}`);
      }

      const data = await response.json();
      return data.id;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to submit transcription";
      toast.error(errorMessage);
      throw error;
    }
  },

  async getTranscript(transcriptId: string): Promise<TranscriptResponse> {
    try {
      const response = await fetch(`${API_BASE_URL}/transcript/${transcriptId}`, {
        method: "GET",
        headers: {
          authorization: API_KEY,
          "content-type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Get transcript failed with status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to get transcript";
      toast.error(errorMessage);
      throw error;
    }
  },

  async pollTranscriptionStatus(transcriptId: string, onUpdate: (status: TranscriptResponse) => void): Promise<TranscriptResponse> {
    let transcript: TranscriptResponse;
    
    do {
      transcript = await this.getTranscript(transcriptId);
      onUpdate(transcript);
      
      if (transcript.status === 'error') {
        throw new Error(transcript.error || "Transcription failed");
      }
      
      if (transcript.status !== 'completed') {
        await new Promise(resolve => setTimeout(resolve, 3000)); // Poll every 3 seconds
      }
    } while (transcript.status !== 'completed');
    
    return transcript;
  }
};
